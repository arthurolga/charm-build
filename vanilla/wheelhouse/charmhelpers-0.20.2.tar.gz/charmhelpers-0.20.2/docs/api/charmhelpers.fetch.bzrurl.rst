charmhelpers.fetch.bzrurl module
================================

.. automodule:: charmhelpers.fetch.bzrurl
    :members:
    :undoc-members:
    :show-inheritance: